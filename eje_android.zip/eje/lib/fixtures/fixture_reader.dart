import 'dart:io';

String fixture(String name) => File('lib/fixtures/$name').readAsStringSync();